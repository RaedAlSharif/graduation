import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class D_Main extends StatefulWidget {
  String name;
  int id;
   D_Main({Key? key , required this.name , required this.id}) : super(key: key);

  @override
  State<D_Main> createState() => _D_MainState(name , id);

}

class _D_MainState extends State<D_Main> {
   String name;
   int id;
  _D_MainState(this.name , this.id);
   TextEditingController _nameController = TextEditingController();
   TextEditingController _emailController = TextEditingController();
   TextEditingController report = TextEditingController();

   String rep_Doc_id = "";
   String  rep_P_id = "";



   Future send(BuildContext cont) async{
     print(rep_Doc_id);
     print(rep_P_id);
     print(report.text);
     var url = await (Uri.parse("http://localhost/PhpProject1/CreateReport.php")
     );
     var response = await http.post(url , body: {
       "idDoctors" : rep_Doc_id,
       "idPatients" : rep_P_id,
       "CONTENT" : report.text,
     });
     var data = json.decode(response.body);
     print(data);
   }

   String error_M = "";
  @override
  Widget build(BuildContext context) {
   return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title:  Text('TabBar Sample'),
          bottom:  TabBar(
            tabs: <Widget>[
              Tab(
                text: "Home",
              ),
              Tab(
                text: "Provide Reports",
              ),
              Tab(
                text: "Schedule",
              ),
            ],
          ),
        ),
        body:  TabBarView(
          children: [
             Scaffold(
                body: Column(
                  children: [
                    Text("Welcome Doctor, " + name + "\n\n\n" ,
                      style: TextStyle(fontSize: 30 , color: Colors.blueAccent),
                    ),
                    Text("You can Provide medical Reports for patients that had an appointment with you!! \n\n" ,
                      style: TextStyle(
                        fontSize: 25, color: Colors.orange
                      ),
                    ),
                    Text("You can add the date and time of the times that you will be "
                        "unavailable at in order to prevent patients from requesting any appointmentss at those times!!" ,
                      style: TextStyle(
                          fontSize: 25, color: Colors.orange
                      ),
                    )
                  ],
                ),
              ),


              Scaffold(
                body: Column(
                  children:  [
                    TextField(
                      controller: _nameController,
                      decoration: const InputDecoration(
                        labelText: 'Patient name',
                      ),
                    ),
                    TextField(
                      controller: _emailController,
                      decoration: const InputDecoration(
                        labelText: 'Patient E-mail',
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        for (int i =0 ; i< products.length;i++){
                          if (products[i]["idDoctors"] == id){
                            if(products[i]["name"] == _nameController.text){
                              if(products[i]["email"] == _emailController.text){
                                print("ture");
                                setState(() {
                                  rep_Doc_id = products[i]["idDoctors"];
                                  rep_P_id = products[i]["idPatients"];
                                });
                              }
                            }
                          }
                        }
                      },
                      child: Text('Check Patient'),
                    ),
                    TextField(
                      controller: report,
                      maxLines: 8,
                      decoration: const InputDecoration(
                        labelText: 'Write the report here',

                      ),
                    ),
                    ElevatedButton(onPressed: () {
                      if(_nameController.text.isNotEmpty && _emailController.text.isNotEmpty && report.text.isNotEmpty){
                      for (int i =0 ; i< products.length;i++){
                        if (products[i]["idDoctors"] == id){
                          if(products[i]["name"] == _nameController.text){
                            if(products[i]["email"] == _emailController.text){
                              print("ture");
                              //String x = products[i]["idDoctors"].toString();
                              setState(() {
                                rep_Doc_id = products[i]["idDoctors"].toString();
                                rep_P_id = products[i]["idPatients"].toString();
                              });
                              send(context);
                              Success();
                            }
                          }
                        }
                      }
                      }

                    },
                        child: const Text("Send Report"))

                  ],
                ),
              ),
Scaffold(

)
          ],
        ),
      ),
    );

  }
  List products = [];
   getData() async {
     var url = await (Uri.parse("http://localhost/PhpProject1/SignIn.php"));
     var response = await http.get(url);
     if ( response.statusCode == 200){
       setState(() {
         products = json.decode(response.body);
       });
     }
     print(products);
     print("above me");
     return products;
   }

   @override
   void initState() {
     super.initState();
     getData();
     //newp = getData();
   }

  /* Future<Widget> Report()async {
    return Scaffold(
       body: Column(
         children: [
           TextField(
             controller: report,
             maxLines: 8,
             decoration: const InputDecoration(
               labelText: 'Write the report here',

             ),
           ),
           ElevatedButton(onPressed: () {
             send(context);
             Success();
           },
               child: const Text("Send Report"))
         ],
       ),
     );
   }*/
   Future Success() => showDialog(
     context: context,
     builder: (context) => const AlertDialog(
       backgroundColor: Colors.black45,
       title: Text("Appointment requested successfully",
           style: TextStyle(color: Colors.yellowAccent)
       ),
       content:Text("You will be contacted shortly about the status of your request!" + "\n"
           "Thank you for choosing Specialization zone", style: TextStyle(color: Colors.white)),

     ),
   );
}
