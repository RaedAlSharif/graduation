import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'Doctor_Main_Page.dart';
import 'user_login.dart';
import 'doctorsignup.dart';
import 'forgot_password.dart';

class DoctorLogin extends StatefulWidget {
  @override
  _DoctorLoginState createState() => _DoctorLoginState();
}

class _DoctorLoginState extends State<DoctorLogin> {
  TextEditingController _nameController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
  List products = [];
  getData() async {
    var url = await (Uri.parse("http://localhost/PhpProject1/Doctors_SingIn.php"));
    var response = await http.get(url);
    if ( response.statusCode == 200){
      setState(() {
        products = json.decode(response.body);
      });
    }
    print(products);
    print("above me");
    return products;
  }

  @override
  void initState() {
    super.initState();
    getData();
    //newp = getData();
  }
String error_M = "";
  void _login() {
    String name = _nameController.text;
    String password = _passwordController.text;

    for (int i = 0; i < products.length; i++) {
      if (products[i]["name"] == name) {
        if (products[i]["password"] == password) {
          print(products[i]["idDoctors"]);
          Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => D_Main(name: name, id: products[i]["idDoctors"] )));
        }
        }
        }
    setState(() {
      error_M = "Invalid Inquires";
    });


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctor Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Email',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(
                labelText: 'Password',
              ),
              obscureText: true,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: _login,
              child: Text('Login'),
            ),
            TextButton(
              onPressed: () {
                // Implement the forgot password logic here
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ForgotPassword()),
                );
              },
              child: Text('Forgot Password'),
            ),
            SizedBox(height: 16.0),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => UserLogin()),
                );
              },
              child: const Text(
                'Login for User',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
            Text(error_M , style: TextStyle(color: Colors.red),)
          ],
        ),
      ),
    );
  }

}
