import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'MainPage.dart';
import 'UserSignup.dart';
import 'doctor_login.dart';
import 'forgot_password.dart';
import 'package:http/http.dart' as http;

import 'main.dart';
class UserLogin extends StatefulWidget {
  int unit = 0;
   List products = [];
  @override
  _UserLoginState createState() => _UserLoginState();
}

class _UserLoginState extends State<UserLogin> {
  TextEditingController nameController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
@override
  // TODO: implement widget


  getData() async {
    var url = await (Uri.parse("http://localhost/PhpProject1/SignIn.php"));
    var response = await http.get(url);
    if ( response.statusCode == 200){
      setState(() {
        widget.products = json.decode(response.body);
      });
    }
    print(widget.products);
    print("above me");
    return widget.products;
  }

  @override
  void initState() {
    super.initState();
    getData();
    //newp = getData();
  }

  String error_message = "";

  void _goToSignUp() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => UserSignup()),
    );
  }

  void _goToForgotPassword() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ForgotPassword()),
    );
  }

  bool met(){
    for (int i = 0; i < widget.products.length; i++) {
      if (widget.products[i]["name"] == nameController.text) {
        if (widget.products[i]["password"] == _passwordController.text) {
          setState(() {
            widget.unit = i;
          });
          return true;
        }
        }
        }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('User Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Email',
              ),
            ),
            SizedBox(height: 16.0),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(
                labelText: 'Password',
              ),
              obscureText: true,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                  if (met()){
                      //Navigator.of(context).push(MaterialPageRoute(builder: (context) => MainPage(products: widget.products)));
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MainPage(products: widget.products , unit: widget.unit,)),
                      );
                    }
                  else{
                    /*else{
         error_message = "Password Incorrect";
        }
      }
      else{
        error_message = "Name Unavailable or incorrect";
      }*/
                  }
    setState(() {
                    error_message = "Incorrect inquires";
                    });
              },
              child: Text('Login'),
            ),
            SizedBox(height: 16.0),
            TextButton(
              onPressed: _goToSignUp,
              child: Text('Sign Up'),
            ),
            TextButton(
              onPressed: _goToForgotPassword,
              child: Text('Forgot Password'),
            ),
            SizedBox(height: 16.0),
            GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => DoctorLogin()),
                );
              },
              child: const Text(
                'Login for Doctor',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
            Text(error_message)
          ],
        ),
      ),
    );
  }

}
